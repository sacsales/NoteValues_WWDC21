import UIKit
import PlaygroundSupport
import SwiftUI
import Foundation
import AVFoundation

/*

 beep boop
 note: please use this on full screen on an ipad for best experience. make sure it's not on silent too.  thanks!
** Also, please TURN OFF the ENABLE RESULTS switch! The playground tends to crash randomly with it on.**
 
I'm still a little new to using playgrounds (I usually rely on IB. Whoops!), so my code may be a little inefficent for now. When I was stuck with some of the code, I visited the apple developer documentation and a website called hackingwithswift. Constraints were a little confusing at first.
There's probably a much easier way to make this whole thing, but my main priority is that it works, which hopefully it does by the time I submit this.
 In all seriousness, I hope you like my playground! Have an awesome day/night :]
 
 - Sabrina, 12
 
*/



//these each measure a third of the screen to help with positioning buttons and other stuff. these may be invisible.
let bottomThird = UIView()
bottomThird.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)

let middleThird = UIView()
middleThird.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)

let topThird = UIView()
topThird.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
//view controller


var pageNumber = 0
let mainFrameOfView = CGRect(x: 0, y: 0, width: 700, height: 500)


let nextButton = UIButton()
let nextButtonView = UIImage(named: "Next_Button_.png")
nextButton.setTitle("Next >", for: .normal)
nextButton.setTitleColor(.black, for: .normal)
nextButton.alpha = 0

let backButton = UIButton()
backButton.setTitle("< Back", for: .normal)
backButton.setTitleColor(.black, for: .normal)


//play button properties
let playButtonImage = UIImage(named: "PlayButton_.png")
let playButton = UIButton()
playButton.setBackgroundImage(playButtonImage, for: .normal)


//logo and page header created
let titleImage = UIImage(named: "logo.PSD")
let titleImageView =  UIImageView(image: titleImage)
titleImageView.alpha = 0

let titleIconImage = UIImage(named: "drumIcon.jpg")
let titleIconView = UIImageView(image: titleIconImage)
titleIconView.alpha = 0


let notationExample = UIImage(named: "notationExampleShot.jpeg")
let notationExampleView = UIImageView(image: notationExample)
notationExampleView.alpha = 0







let staffExample = UIImage(named: "staffExample_.png")
let staffExampleView = UIImageView(image: staffExample)
staffExampleView.alpha = 0


let wholeNote = UIImage(named: "wholeNote 2.png")
let wholeNoteView = UIButton()
wholeNoteView.setBackgroundImage(wholeNote, for: .normal)
wholeNoteView.alpha = 0


let titleSubtext = UILabel()
titleSubtext.text = ("A brief tutorial on rhythm and beat for drums.")
titleSubtext.textColor = .black
titleSubtext.alpha = 0


//page text properties: assign content at page function instead
let pageText = UILabel()
pageText.text = ("")
pageText.textColor = .black
pageText.numberOfLines = 8
pageText.alpha = 0
//quarter tiles

let centerText = UILabel()
centerText.text = ""
centerText.numberOfLines = 0
centerText.textAlignment = .center

let quarterReal = UIImage(named: "quarterReal.png")
let quarterNumber = UIImage(named: "quarterUp.png")
let quarterExView = UIImageView(image: quarterReal)

let eighthReal = UIImage(named: "eighthReal.png")
let eighthNumber = UIImage(named: "eighthNumberEx.png")
let eighthExView = UIImageView(image: eighthReal)

let sixteenthReal = UIImage(named: "sixteenthReal.png")
let sixteenthNumber = UIImage(named: "sixteenExNumber.png")
let sixteenthExView = UIImageView(image: sixteenthReal)


let quarterImageDown = UIImage(named:"quarterDown.png")
let quarterImageUp = UIImage(named:"quarterUp.png")
let eighthImageDown = UIImage(named:"eighthDown.png")
let eighthImageUp = UIImage(named:"eighthUp.png")
let sixteenthImageDown = UIImage(named:"sixteenDown.png")
let sixteenthImageUp = UIImage(named:"sixteenUp.png")
 
let quarterTile1 = UIButton()
quarterTile1.setImage(quarterImageDown, for: .normal)

let quarterTile2 = UIButton()
quarterTile2.setImage(quarterImageDown, for: .normal)

let quarterTile3 = UIButton()
quarterTile3.setImage(quarterImageDown, for: .normal)

let quarterTile4 = UIButton()
quarterTile4.setImage(quarterImageDown, for: .normal)

var quarterTile1isOn = false
var quarterTile2isOn = false
var quarterTile3isOn = false
var quarterTile4isOn = false

var quarterTileArray = [quarterTile1isOn,quarterTile2isOn,quarterTile3isOn,quarterTile4isOn]
var quarterSoundEffect: AVAudioPlayer?
let quarterPath = Bundle.main.path(forResource: "Quarter.m4a", ofType:nil)!
let quarterUrl = URL(fileURLWithPath: quarterPath)




var eighthSoundEffect: AVAudioPlayer?
let eighthPath = Bundle.main.path(forResource: "Quarter.m4a", ofType:nil)!
let eighthUrl = URL(fileURLWithPath: eighthPath)

//eighth tiles!





let startButton = UIButton()
startButton.setTitle("Start!", for: .normal)
startButton.backgroundColor = #colorLiteral(red: 1, green: 0.4399022162, blue: 0.3658145666, alpha: 1)
startButton.alpha = 0



let countGuide1 = UILabel()
countGuide1.text = "1"

let countGuide2 = UILabel()
countGuide2.text = "2"

let countGuide3 = UILabel()
countGuide3.text = "3"

let countGuide4 = UILabel()
countGuide4.text = "4"

let quarterCountStackView = UIStackView()
quarterCountStackView.axis  = NSLayoutConstraint.Axis.horizontal
quarterCountStackView.distribution  = UIStackView.Distribution.equalSpacing
quarterCountStackView.alignment = UIStackView.Alignment.center
quarterCountStackView.spacing   = 16.0

let quarterCountGuides = [countGuide1,countGuide2,countGuide3,countGuide4]

let eighthGuide1 = UILabel()
eighthGuide1.text = "1"

let eighthGuide2 = UILabel()
eighthGuide2.text = "1n"

let eighthGuide3 = UILabel()
eighthGuide3.text = "2"

let eighthGuide4 = UILabel()
eighthGuide4.text = "2n"

let eighthGuide5 = UILabel()
eighthGuide5.text = "3"

let eighthGuide6 = UILabel()
eighthGuide6.text = "3n"

let eighthGuide7 = UILabel()
eighthGuide7.text = "4"

let eighthGuide8 = UILabel()
eighthGuide8.text = "4n"


let sixteenGuide1 = UILabel()
sixteenGuide1.text = "1"

let sixteenGuide2 = UILabel()
sixteenGuide2.text = "1e"

let sixteenGuide3 = UILabel()
sixteenGuide3.text = "1n"

let sixteenGuide4 = UILabel()
sixteenGuide4.text = "1a"

let sixteenGuide5 = UILabel()
sixteenGuide5.text = "2"

let sixteenGuide6 = UILabel()
sixteenGuide6.text = "2e"

let sixteenGuide7 = UILabel()
sixteenGuide7.text = "2n"

let sixteenGuide8 = UILabel()
sixteenGuide8.text = "2a"

let sixteenGuide9 = UILabel()
sixteenGuide9.text = "3"

let sixteenGuide10 = UILabel()
sixteenGuide10.text = "3e"

let sixteenGuide11 = UILabel()
sixteenGuide11.text = "3n"

let sixteenGuide12 = UILabel()
sixteenGuide12.text = "3a"

let sixteenGuide13 = UILabel()
sixteenGuide13.text = "4"

let sixteenGuide14 = UILabel()
sixteenGuide14.text = "4e"

let sixteenGuide15 = UILabel()
sixteenGuide15.text = "4n"

let sixteenGuide16 = UILabel()
sixteenGuide16.text = "4a"

let quarterStackView = UIStackView()
quarterStackView.axis  = NSLayoutConstraint.Axis.horizontal
quarterStackView.distribution  = UIStackView.Distribution.equalSpacing
quarterStackView.alignment = UIStackView.Alignment.center
quarterStackView.spacing   = 16.0


quarterStackView.addArrangedSubview(quarterTile1)
quarterStackView.addArrangedSubview(quarterTile2)
quarterStackView.addArrangedSubview(quarterTile3)
quarterStackView.addArrangedSubview(quarterTile4)


let eighthStackView = UIStackView()
eighthStackView.axis  = NSLayoutConstraint.Axis.horizontal
eighthStackView.distribution  = UIStackView.Distribution.equalSpacing
eighthStackView.alignment = UIStackView.Alignment.center
eighthStackView.spacing   = 8.0

let eighthTile1 = UIButton()
eighthTile1.setImage(eighthImageDown, for: .normal)

let eighthTile2 = UIButton()
eighthTile2.setImage(eighthImageDown, for: .normal)

let eighthTile3 = UIButton()
eighthTile3.setImage(eighthImageDown, for: .normal)

let eighthTile4 = UIButton()
eighthTile4.setImage(eighthImageDown, for: .normal)

let eighthTile5 = UIButton()
eighthTile5.setImage(eighthImageDown, for: .normal)

let eighthTile6 = UIButton()
eighthTile6.setImage(eighthImageDown, for: .normal)

let eighthTile7 = UIButton()
eighthTile7.setImage(eighthImageDown, for: .normal)

let eighthTile8 = UIButton()
eighthTile8.setImage(eighthImageDown, for: .normal)

eighthStackView.addArrangedSubview(eighthTile1)
eighthStackView.addArrangedSubview(eighthTile2)
eighthStackView.addArrangedSubview(eighthTile3)
eighthStackView.addArrangedSubview(eighthTile4)
eighthStackView.addArrangedSubview(eighthTile5)
eighthStackView.addArrangedSubview(eighthTile6)
eighthStackView.addArrangedSubview(eighthTile7)
eighthStackView.addArrangedSubview(eighthTile8)


var eighthTile1IsOn = false
var eighthTile2IsOn = false
var eighthTile3IsOn = false
var eighthTile4IsOn = false
var eighthTile5IsOn = false
var eighthTile6IsOn = false
var eighthTile7IsOn = false
var eighthTile8IsOn = false


var eighthTiles = [eighthTile1IsOn,eighthTile2IsOn,eighthTile3IsOn,eighthTile4IsOn,eighthTile5IsOn,eighthTile6IsOn,eighthTile7IsOn,eighthTile8IsOn]



let sixteenthStackView = UIStackView()
sixteenthStackView.axis  = NSLayoutConstraint.Axis.horizontal
sixteenthStackView.distribution  = UIStackView.Distribution.equalSpacing
sixteenthStackView.alignment = UIStackView.Alignment.center
sixteenthStackView.spacing   = 8.0

let sixteenthTile1 = UIButton()
sixteenthTile1.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile2 = UIButton()
sixteenthTile2.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile3 = UIButton()
sixteenthTile3.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile4 = UIButton()
sixteenthTile4.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile5 = UIButton()
sixteenthTile5.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile6 = UIButton()
sixteenthTile6.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile7 = UIButton()
sixteenthTile7.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile8 = UIButton()
sixteenthTile8.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile9 = UIButton()
sixteenthTile9.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile10 = UIButton()
sixteenthTile10.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile11 = UIButton()
sixteenthTile11.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile12 = UIButton()
sixteenthTile12.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile13 = UIButton()
sixteenthTile13.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile14 = UIButton()
sixteenthTile14.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile15 = UIButton()
sixteenthTile15.setImage(sixteenthImageDown, for: .normal)

let sixteenthTile16 = UIButton()
sixteenthTile16.setImage(sixteenthImageDown, for: .normal)


var sixteenthTile1IsOn = false
var sixteenthTile2IsOn = false
var sixteenthTile3IsOn = false
var sixteenthTile4IsOn = false
var sixteenthTile5IsOn = false
var sixteenthTile6IsOn = false
var sixteenthTile7IsOn = false
var sixteenthTile8IsOn = false
var sixteenthTile9IsOn = false
var sixteenthTile10IsOn = false
var sixteenthTile11IsOn = false
var sixteenthTile12IsOn = false
var sixteenthTile13IsOn = false
var sixteenthTile14IsOn = false
var sixteenthTile15IsOn = false
var sixteenthTile16IsOn = false

var sixteenthTileArray = [sixteenthTile1IsOn,
                          sixteenthTile2IsOn,
                          sixteenthTile3IsOn,
                          sixteenthTile4IsOn,
                          sixteenthTile5IsOn,
                          sixteenthTile6IsOn,
                          sixteenthTile7IsOn,
                          sixteenthTile8IsOn,
                          sixteenthTile9IsOn,
                          sixteenthTile10IsOn,
                          sixteenthTile11IsOn,
                          sixteenthTile12IsOn,
                          sixteenthTile13IsOn,
                          sixteenthTile14IsOn,
                          sixteenthTile15IsOn,
                          sixteenthTile16IsOn,
                                            ]

sixteenthStackView.addArrangedSubview(sixteenthTile1)
sixteenthStackView.addArrangedSubview(sixteenthTile2)
sixteenthStackView.addArrangedSubview(sixteenthTile3)
sixteenthStackView.addArrangedSubview(sixteenthTile4)

sixteenthStackView.addArrangedSubview(sixteenthTile5)
sixteenthStackView.addArrangedSubview(sixteenthTile6)
sixteenthStackView.addArrangedSubview(sixteenthTile7)
sixteenthStackView.addArrangedSubview(sixteenthTile8)

sixteenthStackView.addArrangedSubview(sixteenthTile9)
sixteenthStackView.addArrangedSubview(sixteenthTile10)
sixteenthStackView.addArrangedSubview(sixteenthTile11)
sixteenthStackView.addArrangedSubview(sixteenthTile12)

sixteenthStackView.addArrangedSubview(sixteenthTile13)
sixteenthStackView.addArrangedSubview(sixteenthTile14)
sixteenthStackView.addArrangedSubview(sixteenthTile15)
sixteenthStackView.addArrangedSubview(sixteenthTile16)



let page3StackView = UIStackView()
page3StackView.axis  = NSLayoutConstraint.Axis.horizontal
page3StackView.distribution  = UIStackView.Distribution.equalSpacing
page3StackView.alignment = UIStackView.Alignment.center


page3StackView.addArrangedSubview(quarterExView)
page3StackView.addArrangedSubview(eighthExView)
page3StackView.addArrangedSubview(sixteenthExView)
page3StackView.alpha = 0



let resetButton = UIButton()
resetButton.setTitle("Reset Tiles", for: .normal)
resetButton.backgroundColor = #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1)
resetButton.setTitleColor(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), for: .normal)

class ViewController: UIViewController {
    
    override func viewDidAppear(_ _animated: Bool) {
        
        //constraints! touch one thing, and the whole layout messes up.
        startButton.translatesAutoresizingMaskIntoConstraints = false
       
        titleSubtext.translatesAutoresizingMaskIntoConstraints = false
        titleImageView.translatesAutoresizingMaskIntoConstraints = false
        titleIconView.translatesAutoresizingMaskIntoConstraints = false
        
        bottomThird.translatesAutoresizingMaskIntoConstraints = false
        middleThird.translatesAutoresizingMaskIntoConstraints = false
        topThird.translatesAutoresizingMaskIntoConstraints = false
        
        playButton.translatesAutoresizingMaskIntoConstraints = false
        nextButton.translatesAutoresizingMaskIntoConstraints = false
        
        quarterTile1.translatesAutoresizingMaskIntoConstraints = false
        quarterTile2.translatesAutoresizingMaskIntoConstraints = false
        quarterTile3.translatesAutoresizingMaskIntoConstraints = false
        quarterTile4.translatesAutoresizingMaskIntoConstraints = false
        
        
        
        quarterStackView.translatesAutoresizingMaskIntoConstraints = false
        
        pageText.translatesAutoresizingMaskIntoConstraints = false
        
        notationExampleView.translatesAutoresizingMaskIntoConstraints = false
        quarterExView.translatesAutoresizingMaskIntoConstraints = false
        eighthExView.translatesAutoresizingMaskIntoConstraints = false
        sixteenthExView.translatesAutoresizingMaskIntoConstraints = false
        page3StackView.translatesAutoresizingMaskIntoConstraints = false
        staffExampleView.translatesAutoresizingMaskIntoConstraints = false
        wholeNoteView.translatesAutoresizingMaskIntoConstraints = false
        countGuide1.translatesAutoresizingMaskIntoConstraints = false
        countGuide2.translatesAutoresizingMaskIntoConstraints = false
        countGuide3.translatesAutoresizingMaskIntoConstraints = false
        countGuide4.translatesAutoresizingMaskIntoConstraints = false
        quarterCountStackView.translatesAutoresizingMaskIntoConstraints = false
        backButton.translatesAutoresizingMaskIntoConstraints = false
        
        
        eighthStackView.translatesAutoresizingMaskIntoConstraints = false
        
        eighthTile1.translatesAutoresizingMaskIntoConstraints = false
        eighthTile2.translatesAutoresizingMaskIntoConstraints = false
        eighthTile3.translatesAutoresizingMaskIntoConstraints = false
        eighthTile4.translatesAutoresizingMaskIntoConstraints = false
        eighthTile5.translatesAutoresizingMaskIntoConstraints = false
        eighthTile6.translatesAutoresizingMaskIntoConstraints = false
        eighthTile7.translatesAutoresizingMaskIntoConstraints = false
        eighthTile8.translatesAutoresizingMaskIntoConstraints = false
        
        sixteenthStackView.translatesAutoresizingMaskIntoConstraints = false
        
        sixteenthTile1.translatesAutoresizingMaskIntoConstraints = false
        sixteenthTile2.translatesAutoresizingMaskIntoConstraints = false
        sixteenthTile3.translatesAutoresizingMaskIntoConstraints = false
        sixteenthTile4.translatesAutoresizingMaskIntoConstraints = false
        
        sixteenthTile5.translatesAutoresizingMaskIntoConstraints = false
        sixteenthTile6.translatesAutoresizingMaskIntoConstraints = false
        sixteenthTile7.translatesAutoresizingMaskIntoConstraints = false
        sixteenthTile8.translatesAutoresizingMaskIntoConstraints = false
        
        sixteenthTile9.translatesAutoresizingMaskIntoConstraints = false
        sixteenthTile10.translatesAutoresizingMaskIntoConstraints = false
        sixteenthTile11.translatesAutoresizingMaskIntoConstraints = false
        sixteenthTile12.translatesAutoresizingMaskIntoConstraints = false
        
        sixteenthTile13.translatesAutoresizingMaskIntoConstraints = false
        sixteenthTile14.translatesAutoresizingMaskIntoConstraints = false
        sixteenthTile15.translatesAutoresizingMaskIntoConstraints = false
        sixteenthTile16.translatesAutoresizingMaskIntoConstraints = false
        
        resetButton.translatesAutoresizingMaskIntoConstraints = false
        
        
        eighthGuide1.translatesAutoresizingMaskIntoConstraints = false
        eighthGuide2.translatesAutoresizingMaskIntoConstraints = false
        eighthGuide3.translatesAutoresizingMaskIntoConstraints = false
        eighthGuide4.translatesAutoresizingMaskIntoConstraints = false
        eighthGuide5.translatesAutoresizingMaskIntoConstraints = false
        eighthGuide6.translatesAutoresizingMaskIntoConstraints = false
        eighthGuide7.translatesAutoresizingMaskIntoConstraints = false
        eighthGuide8.translatesAutoresizingMaskIntoConstraints = false
        
        
        centerText.translatesAutoresizingMaskIntoConstraints = false
        
        sixteenGuide1.translatesAutoresizingMaskIntoConstraints = false
        sixteenGuide2.translatesAutoresizingMaskIntoConstraints = false
        sixteenGuide3.translatesAutoresizingMaskIntoConstraints = false
        sixteenGuide4.translatesAutoresizingMaskIntoConstraints = false
        
        sixteenGuide5.translatesAutoresizingMaskIntoConstraints = false
        sixteenGuide6.translatesAutoresizingMaskIntoConstraints = false
        sixteenGuide7.translatesAutoresizingMaskIntoConstraints = false
        sixteenGuide8.translatesAutoresizingMaskIntoConstraints = false
        
        sixteenGuide9.translatesAutoresizingMaskIntoConstraints = false
        sixteenGuide10.translatesAutoresizingMaskIntoConstraints = false
        sixteenGuide11.translatesAutoresizingMaskIntoConstraints = false
        sixteenGuide12.translatesAutoresizingMaskIntoConstraints = false
        
        sixteenGuide13.translatesAutoresizingMaskIntoConstraints = false
        sixteenGuide14.translatesAutoresizingMaskIntoConstraints = false
        sixteenGuide15.translatesAutoresizingMaskIntoConstraints = false
        sixteenGuide16.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            
            
            centerText.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            centerText.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            centerText.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 20),
            centerText.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -20),
            
            //this measures a third of the screen. base the start button's constraint on this to make it proportionate :D
            bottomThird.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            bottomThird.widthAnchor.constraint(equalTo: view.widthAnchor),
            bottomThird.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 1/3),
            bottomThird.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            middleThird.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            middleThird.widthAnchor.constraint(equalTo: view.widthAnchor),
            middleThird.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 1/3),
            middleThird.bottomAnchor.constraint(equalTo: bottomThird.topAnchor),
            
            topThird.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            topThird.widthAnchor.constraint(equalTo: view.widthAnchor),
            topThird.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 1/3),
            topThird.bottomAnchor.constraint(equalTo: middleThird.topAnchor),
            
            //start button
            startButton.centerXAnchor.constraint(equalTo: bottomThird.centerXAnchor),
            startButton.centerYAnchor.constraint(equalTo: bottomThird.centerYAnchor),
            startButton.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1/3),
            startButton.heightAnchor.constraint(equalToConstant: 50),
            
            //hand drawn icon
           
            
            
            //title view
            titleImageView.topAnchor.constraint(equalTo: view.topAnchor, constant: 2),
            titleImageView.heightAnchor.constraint(equalTo: topThird.heightAnchor),
            titleImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            titleImageView.bottomAnchor.constraint(equalTo: topThird.bottomAnchor, constant: 20),
            titleImageView.widthAnchor.constraint(equalTo: topThird.widthAnchor, multiplier: 5/6),
            
            titleIconView.centerXAnchor.constraint(equalTo: middleThird.centerXAnchor),
            titleIconView.centerYAnchor.constraint(equalTo: middleThird.centerYAnchor),
            titleIconView.widthAnchor.constraint(equalTo : view.widthAnchor, multiplier: 1/3),
            titleIconView.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
    
            //"for drums" subview
           
            titleSubtext.centerXAnchor.constraint(equalTo: topThird.centerXAnchor),
            titleSubtext.bottomAnchor.constraint(equalTo: middleThird.topAnchor),
            
        
            
            
            
            //play button
            playButton.centerYAnchor.constraint(equalTo: bottomThird.centerYAnchor, constant: -20),
            playButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            playButton.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1/7),
            playButton.heightAnchor.constraint(equalTo: bottomThird.heightAnchor, constant: -60),
            
            
            //next button
            nextButton.centerYAnchor.constraint(equalTo: bottomThird.centerYAnchor),
            nextButton.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -20),
            
            
            
            //quarter tiles! note: only create width and height constraints. the stack view will take care of spacing.
            
            quarterTile1.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/5),
            quarterTile1.heightAnchor.constraint(equalTo: middleThird.heightAnchor,constant: -20),
            
            quarterTile2.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/5),
            quarterTile2.heightAnchor.constraint(equalTo: middleThird.heightAnchor,constant: -20),
            
            quarterTile3.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/5),
            quarterTile3.heightAnchor.constraint(equalTo: middleThird.heightAnchor,constant: -20),
            
            quarterTile4.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/5),
            quarterTile4.heightAnchor.constraint(equalTo: middleThird.heightAnchor,constant: -20),
            
            //main quarter stack view!
            
            quarterStackView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 20),
            quarterStackView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -20),
            quarterStackView.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            quarterStackView.centerYAnchor.constraint(equalTo: middleThird.centerYAnchor),
            quarterStackView.centerXAnchor.constraint(equalTo: middleThird.centerXAnchor),
            
            
            eighthStackView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 20),
            eighthStackView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -20),
            eighthStackView.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            eighthStackView.centerYAnchor.constraint(equalTo: middleThird.centerYAnchor),
            eighthStackView.centerXAnchor.constraint(equalTo: middleThird.centerXAnchor),
            
            
            eighthTile1.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/9),
            eighthTile1.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            
            eighthTile2.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/9),
            eighthTile2.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            eighthTile3.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/9),
            eighthTile3.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            eighthTile4.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/9),
            eighthTile4.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            eighthTile5.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/9),
            eighthTile5.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            eighthTile6.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/9),
            eighthTile6.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            eighthTile7.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/9),
            eighthTile7.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            eighthTile8.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/9),
            eighthTile8.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            
            
            sixteenthTile1.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile1.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            sixteenthTile2.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile2.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            sixteenthTile3.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile3.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            sixteenthTile4.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile4.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            
            sixteenthTile5.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile5.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            sixteenthTile6.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile6.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            sixteenthTile7.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile7.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
        
            sixteenthTile8.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile8.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
        
            sixteenthTile9.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile9.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            sixteenthTile10.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile10.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            sixteenthTile11.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile11.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            sixteenthTile12.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile12.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            sixteenthTile13.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile13.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            sixteenthTile14.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile14.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            sixteenthTile15.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile15.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            sixteenthTile16.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/18),
            sixteenthTile16.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            
            
            sixteenthStackView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 20),
            sixteenthStackView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -20),
            sixteenthStackView.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            sixteenthStackView.centerYAnchor.constraint(equalTo: middleThird.centerYAnchor),
            sixteenthStackView.centerXAnchor.constraint(equalTo: middleThird.centerXAnchor),
            
            pageText.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            pageText.centerYAnchor.constraint(equalTo: topThird.centerYAnchor),
            pageText.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 20),
            pageText.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -20),
            
            
            notationExampleView.centerYAnchor.constraint(equalTo: middleThird.centerYAnchor),
            notationExampleView.centerXAnchor.constraint(equalTo: middleThird.centerXAnchor),
            notationExampleView.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            notationExampleView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 2/5),
            
            staffExampleView.centerYAnchor.constraint(equalTo: middleThird.centerYAnchor),
            staffExampleView.centerXAnchor.constraint(equalTo: middleThird.centerXAnchor),
            staffExampleView.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            staffExampleView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 3/5),
            
            
            wholeNoteView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            wholeNoteView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -20),
            wholeNoteView.widthAnchor.constraint(equalTo: staffExampleView.widthAnchor, multiplier: 1/6),
            wholeNoteView.heightAnchor.constraint(equalTo: staffExampleView.heightAnchor, multiplier: 1/3),
            
            quarterExView.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/5),
            quarterExView.heightAnchor.constraint(equalTo: middleThird.heightAnchor,constant: -20),
            
            eighthExView.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/5),
            eighthExView.heightAnchor.constraint(equalTo: middleThird.heightAnchor,constant: -20),
            
            sixteenthExView.widthAnchor.constraint(equalTo: middleThird.widthAnchor, multiplier: 1/5),
            sixteenthExView.heightAnchor.constraint(equalTo: middleThird.heightAnchor,constant: -20),
            
            page3StackView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 20),
            page3StackView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -20),
            page3StackView.heightAnchor.constraint(equalTo: middleThird.heightAnchor),
            page3StackView.centerYAnchor.constraint(equalTo: middleThird.centerYAnchor),
            page3StackView.centerXAnchor.constraint(equalTo: middleThird.centerXAnchor),
            
            countGuide1.centerXAnchor.constraint(equalTo: quarterTile1.centerXAnchor),
            countGuide1.centerYAnchor.constraint(equalTo: quarterTile1.centerYAnchor, constant: -100),
            
            countGuide2.centerXAnchor.constraint(equalTo: quarterTile2.centerXAnchor),
            countGuide2.centerYAnchor.constraint(equalTo: quarterTile2.centerYAnchor, constant: -100),
            
            
            countGuide3.centerXAnchor.constraint(equalTo: quarterTile3.centerXAnchor),
            countGuide3.centerYAnchor.constraint(equalTo: quarterTile3.centerYAnchor, constant: -100),
            
            countGuide4.centerXAnchor.constraint(equalTo: quarterTile4.centerXAnchor),
            countGuide4.centerYAnchor.constraint(equalTo: quarterTile4.centerYAnchor, constant: -100),
            
            backButton.centerYAnchor.constraint(equalTo: bottomThird.centerYAnchor),
            backButton.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 20),
            
            
            resetButton.topAnchor.constraint(equalTo: startButton.bottomAnchor, constant: 10),
            resetButton.widthAnchor.constraint(equalTo: playButton.widthAnchor),
            resetButton.heightAnchor.constraint(equalToConstant: 35),
            resetButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            resetButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -15),

          
            eighthGuide1.centerXAnchor.constraint(equalTo: eighthTile1.centerXAnchor),
            eighthGuide1.centerYAnchor.constraint(equalTo: eighthTile1.centerYAnchor, constant: -100),
            
            eighthGuide2.centerXAnchor.constraint(equalTo: eighthTile2.centerXAnchor),
            eighthGuide2.centerYAnchor.constraint(equalTo: eighthTile2.centerYAnchor, constant: -100),
            
            eighthGuide3.centerXAnchor.constraint(equalTo: eighthTile3.centerXAnchor),
            eighthGuide3.centerYAnchor.constraint(equalTo: eighthTile3.centerYAnchor, constant: -100),
            
            eighthGuide4.centerXAnchor.constraint(equalTo: eighthTile4.centerXAnchor),
            eighthGuide4.centerYAnchor.constraint(equalTo: eighthTile4.centerYAnchor, constant: -100),
            
            eighthGuide5.centerXAnchor.constraint(equalTo: eighthTile5.centerXAnchor),
            eighthGuide5.centerYAnchor.constraint(equalTo: eighthTile5.centerYAnchor, constant: -100),
            
            eighthGuide6.centerXAnchor.constraint(equalTo: eighthTile6.centerXAnchor),
            eighthGuide6.centerYAnchor.constraint(equalTo: eighthTile6.centerYAnchor, constant: -100),
            
            eighthGuide7.centerXAnchor.constraint(equalTo: eighthTile7.centerXAnchor),
            eighthGuide7.centerYAnchor.constraint(equalTo: eighthTile7.centerYAnchor, constant: -100),
            
            eighthGuide8.centerXAnchor.constraint(equalTo: eighthTile8.centerXAnchor),
            eighthGuide8.centerYAnchor.constraint(equalTo: eighthTile8.centerYAnchor, constant: -100),
            
            
            sixteenGuide1.centerXAnchor.constraint(equalTo: sixteenthTile1.centerXAnchor),
            sixteenGuide1.centerYAnchor.constraint(equalTo: sixteenthTile1.centerYAnchor, constant: -100),
            
            sixteenGuide2.centerXAnchor.constraint(equalTo: sixteenthTile2.centerXAnchor),
            sixteenGuide2.centerYAnchor.constraint(equalTo: sixteenthTile2.centerYAnchor, constant: -100),
            
            sixteenGuide3.centerXAnchor.constraint(equalTo: sixteenthTile3.centerXAnchor),
            sixteenGuide3.centerYAnchor.constraint(equalTo: sixteenthTile3.centerYAnchor, constant: -100),
            
            sixteenGuide4.centerXAnchor.constraint(equalTo: sixteenthTile4.centerXAnchor),
            sixteenGuide4.centerYAnchor.constraint(equalTo: sixteenthTile4.centerYAnchor, constant: -100),
            
            sixteenGuide5.centerXAnchor.constraint(equalTo: sixteenthTile5.centerXAnchor),
            sixteenGuide5.centerYAnchor.constraint(equalTo: sixteenthTile5.centerYAnchor, constant: -100),
            
            sixteenGuide6.centerXAnchor.constraint(equalTo: sixteenthTile6.centerXAnchor),
            sixteenGuide6.centerYAnchor.constraint(equalTo: sixteenthTile6.centerYAnchor, constant: -100),
            
            sixteenGuide7.centerXAnchor.constraint(equalTo: sixteenthTile7.centerXAnchor),
            sixteenGuide7.centerYAnchor.constraint(equalTo: sixteenthTile7.centerYAnchor, constant: -100),
            
            sixteenGuide8.centerXAnchor.constraint(equalTo: sixteenthTile8.centerXAnchor),
            sixteenGuide8.centerYAnchor.constraint(equalTo: sixteenthTile8.centerYAnchor, constant: -100),
            
            sixteenGuide9.centerXAnchor.constraint(equalTo: sixteenthTile9.centerXAnchor),
            sixteenGuide9.centerYAnchor.constraint(equalTo: sixteenthTile9.centerYAnchor, constant: -100),
            
            sixteenGuide10.centerXAnchor.constraint(equalTo: sixteenthTile10.centerXAnchor),
            sixteenGuide10.centerYAnchor.constraint(equalTo: sixteenthTile10.centerYAnchor, constant: -100),
            
            sixteenGuide11.centerXAnchor.constraint(equalTo: sixteenthTile11.centerXAnchor),
            sixteenGuide11.centerYAnchor.constraint(equalTo: sixteenthTile11.centerYAnchor, constant: -100),
            
            sixteenGuide12.centerXAnchor.constraint(equalTo: sixteenthTile12.centerXAnchor),
            sixteenGuide12.centerYAnchor.constraint(equalTo: sixteenthTile12.centerYAnchor, constant: -100),
            
            sixteenGuide13.centerXAnchor.constraint(equalTo: sixteenthTile13.centerXAnchor),
            sixteenGuide13.centerYAnchor.constraint(equalTo: sixteenthTile13.centerYAnchor, constant: -100),
            
            sixteenGuide14.centerXAnchor.constraint(equalTo: sixteenthTile14.centerXAnchor),
            sixteenGuide14.centerYAnchor.constraint(equalTo: sixteenthTile14.centerYAnchor, constant: -100),
            
            sixteenGuide15.centerXAnchor.constraint(equalTo: sixteenthTile15.centerXAnchor),
            sixteenGuide15.centerYAnchor.constraint(equalTo: sixteenthTile15.centerYAnchor, constant: -100),
            
            sixteenGuide16.centerXAnchor.constraint(equalTo: sixteenthTile16.centerXAnchor),
            sixteenGuide16.centerYAnchor.constraint(equalTo: sixteenthTile16.centerYAnchor, constant: -100),
            
            
        ])
        
        
        //title screen animations :)
        UIView.animate(withDuration: 2) {
            titleImageView.alpha = 1.0
            titleSubtext.alpha = 1.0
            titleIconView.alpha = 1.0
            startButton.alpha = 1.0
        }

        
        
    }
    
    override func viewDidLoad() {
        
        func titlePage() {
        //add all subviews here. .isHidden = true for other page contents.
        
        //spacing/layout help
        self.view.frame = mainFrameOfView
        self.view.addSubview(bottomThird)
        self.view.addSubview(middleThird)
        self.view.addSubview(topThird)
            self.view.addSubview(sixteenthStackView)
            
        
        self.view.addSubview(titleImageView)
        self.view.addSubview(titleIconView)
        self.view.addSubview(page3StackView)
        self.view.addSubview(staffExampleView)
            
            self.view.addSubview(eighthStackView)
        self.view.addSubview(startButton)
            self.view.addSubview(resetButton)
        self.view.addSubview(titleSubtext)
        
        //1 1e 1n 1a
        
        self.view.bringSubviewToFront(startButton)
        self.view.addSubview(playButton)
        self.view.addSubview(nextButton)
        
        self.view.addSubview(pageText)
        self.view.addSubview(quarterStackView)
        
            
        self.view.addSubview(notationExampleView)
        self.view.addSubview(wholeNoteView)
        self.view.addSubview(page3StackView)
            
        
        self.view.addSubview(countGuide1)
        self.view.addSubview(countGuide2)
        self.view.addSubview(countGuide3)
        self.view.addSubview(countGuide4)
            
            
        self.view.addSubview(eighthGuide1)
        self.view.addSubview(eighthGuide2)
        self.view.addSubview(eighthGuide3)
        self.view.addSubview(eighthGuide4)
            
        self.view.addSubview(eighthGuide5)
        self.view.addSubview(eighthGuide6)
        self.view.addSubview(eighthGuide7)
        self.view.addSubview(eighthGuide8)
            
        self.view.addSubview(backButton)
        quarterStackView.isHidden = true
        notationExampleView.isHidden = true
        
        nextButton.isHidden = true
        playButton.isHidden = true
        page3StackView.isHidden = true
        wholeNoteView.isHidden = true
        staffExampleView.isHidden = true
        backButton.isHidden = true
        countGuide1.isHidden = true
        countGuide2.isHidden = true
        countGuide3.isHidden = true
        countGuide4.isHidden = true
        eighthStackView.isHidden = false
            eighthStackView.alpha = 0
            sixteenthStackView.isHidden = true
            resetButton.isHidden = true
            eighthGuide1.isHidden = true
            eighthGuide2.isHidden = true
            eighthGuide3.isHidden = true
            eighthGuide4.isHidden = true
            eighthGuide5.isHidden = true
            eighthGuide6.isHidden = true
            eighthGuide7.isHidden = true
            eighthGuide8.isHidden = true
            self.view.bringSubviewToFront(eighthStackView)
            self.view.addSubview(centerText)
            centerText.isHidden = true
            resetButton.isHidden = true
        //just so the text is visible on dark mode
        self.view.backgroundColor = .white
            
            self.view.addSubview(sixteenGuide1)
            self.view.addSubview(sixteenGuide2)
            self.view.addSubview(sixteenGuide3)
            self.view.addSubview(sixteenGuide4)
                
            self.view.addSubview(sixteenGuide5)
            self.view.addSubview(sixteenGuide6)
            self.view.addSubview(sixteenGuide7)
            self.view.addSubview(sixteenGuide8)
            
            self.view.addSubview(sixteenGuide9)
            self.view.addSubview(sixteenGuide10)
            self.view.addSubview(sixteenGuide11)
            self.view.addSubview(sixteenGuide12)
                
            self.view.addSubview(sixteenGuide13)
            self.view.addSubview(sixteenGuide14)
            self.view.addSubview(sixteenGuide15)
            self.view.addSubview(sixteenGuide16)
            
            hideSixteenGuides()
        
        
            

        
        //these make the buttons work...
        startButton.addTarget(self, action: #selector(startButtonPressed(sender:)), for: UIControl.Event.touchUpInside)
        
        nextButton.addTarget(self, action: #selector(nextButtonPressed(sender:)), for: UIControl.Event.touchUpInside)
        
        
        
        quarterTile1.addTarget(self, action: #selector(quarterTile1Pressed(sender:)), for: UIControl.Event.touchUpInside)
        
        quarterTile2.addTarget(self, action: #selector(quarterTile2Pressed(sender:)), for: UIControl.Event.touchUpInside)
        
        quarterTile3.addTarget(self, action: #selector(quarterTile3Pressed(sender:)), for: UIControl.Event.touchUpInside)
        
        quarterTile4.addTarget(self, action: #selector(quarterTile4Pressed(sender:)), for: UIControl.Event.touchUpInside)
        
        playButton.addTarget(self, action: #selector(playButtonPressed(sender:)), for: UIControl.Event.touchUpInside)
            
        wholeNoteView.addTarget(self, action: #selector(wholeNotePressed(sender:)), for: UIControl.Event.touchUpInside)
            
        backButton.addTarget(self, action: #selector(backButtonPressed(sender:)), for: UIControl.Event.touchUpInside)
            
            eighthTile1.addTarget(self, action: #selector(eighthTile1Pressed(sender:)), for: UIControl.Event.touchUpInside)
                
            eighthTile2.addTarget(self, action: #selector(eighthTile2Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            eighthTile3.addTarget(self, action: #selector(eighthTile3Pressed(sender:)), for: UIControl.Event.touchUpInside)
                
            eighthTile4.addTarget(self, action: #selector(eighthTile4Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            eighthTile5.addTarget(self, action: #selector(eighthTile5Pressed(sender:)), for: UIControl.Event.touchUpInside)
                
            eighthTile6.addTarget(self, action: #selector(eighthTile6Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            eighthTile7.addTarget(self, action: #selector(eighthTile7Pressed(sender:)), for: UIControl.Event.touchUpInside)
                
            eighthTile8.addTarget(self, action: #selector(eighthTile8Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile1.addTarget(self, action: #selector(sixteenthTile1Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile2.addTarget(self, action: #selector(sixteenthTile2Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile3.addTarget(self, action: #selector(sixteenthTile3Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile4.addTarget(self, action: #selector(sixteenthTile4Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile5.addTarget(self, action: #selector(sixteenthTile5Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile6.addTarget(self, action: #selector(sixteenthTile6Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile7.addTarget(self, action: #selector(sixteenthTile7Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile8.addTarget(self, action: #selector(sixteenthTile8Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile9.addTarget(self, action: #selector(sixteenthTile9Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile10.addTarget(self, action: #selector(sixteenthTile10Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile11.addTarget(self, action: #selector(sixteenthTile11Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile12.addTarget(self, action: #selector(sixteenthTile12Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile13.addTarget(self, action: #selector(sixteenthTile13Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile14.addTarget(self, action: #selector(sixteenthTile14Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile15.addTarget(self, action: #selector(sixteenthTile15Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            sixteenthTile16.addTarget(self, action: #selector(sixteenthTile16Pressed(sender:)), for: UIControl.Event.touchUpInside)
            
            resetButton.addTarget(self, action: #selector(resetButtonPressed(sender:)), for: UIControl.Event.touchUpInside)
    }
        
        titlePage()
        
        
    } //view did load
     
    @objc func startButtonPressed(sender: UIButton!) {
        
        UIView.animate(withDuration: 0.5) {
            nextButton.alpha = 1.0
            notationExampleView.alpha = 1.0
        }
        pageOne()
        
        
    }
    
    @objc func backButtonPressed(sender: UIButton!) {
         
        pageNumber -= 1
        print(pageNumber + 1)
        
        if pageNumber == 0 {
            
            pageOne()
        }
        if pageNumber == 1 {
                
            pageTwo()
            
            
        } else if pageNumber == 2 {
            
            pageThree()
            page3StackView.isHidden = false
            notationExampleView.isHidden = true
            wholeNoteView.isHidden = true
            
        } else if pageNumber == 3 {
            notationExampleView.isHidden = true
            pageFour()
            
        } else if pageNumber == 4 {
            
            pageFive()
            
        } else if pageNumber == 5 {
            
            pageSix()
            
        } else if pageNumber == 6 {
            
            pageSeven()
            
        } else if pageNumber == 7 {
            
            pageEight()
            
        } else if pageNumber == 8 {
            
            pageNine()
            
        } else if pageNumber == 9 {
            
            pageTen()
            
        } else if pageNumber == 10 {
            
            pageEleven()
            
        } else if pageNumber == 11 {
            
            pageTwelve()
            
        } else if pageNumber == 12 {
            
            pageThirteen()
            
        } else if pageNumber == 13 {
            
            pageFourteen()
            
         } else if pageNumber == 14 {
    
            pageOne()
            pageNumber = 0
        }
        
    
        
   
        
        
    }
    @objc func playButtonPressed(sender: UIButton!) {
        
        
        if pageNumber == 4 || pageNumber == 5 || pageNumber == 6 {
            
            print("this page is a quarter page")
           
            quarterTileArray = [quarterTile1isOn,quarterTile2isOn,quarterTile3isOn,quarterTile4isOn]
        quarterTileArray.forEach { tile in

            if tile == true {
                print(tile)
                do {
                    quarterSoundEffect = try AVAudioPlayer(contentsOf: quarterUrl)
                    quarterSoundEffect?.play()
                } catch {
                    // couldn't load file :(
                }

                
                
            } else if tile == false {
                print(tile)
                
                }
            usleep(1000000)

            
            }
        
        } else if pageNumber == 7 || pageNumber == 8 || pageNumber == 9 {
            
            eighthTiles = [eighthTile1IsOn,eighthTile2IsOn,eighthTile3IsOn,eighthTile4IsOn,eighthTile5IsOn,eighthTile6IsOn,eighthTile7IsOn,eighthTile8IsOn]
            
            eighthTiles.forEach { tile in
                
                if tile == true {
                    
                    print(tile)
                    do {
                        eighthSoundEffect = try AVAudioPlayer(contentsOf: eighthUrl)
                        eighthSoundEffect?.play()
                    } catch {
                        // couldn't load file :(
                    }

                    
                    
                } else if tile == false {
                    
                    print(tile)
                    
                    
                    
                }
                usleep(500000)
            }
            
        } else if pageNumber == 10 || pageNumber == 11 || pageNumber == 12  {
            
            sixteenthTileArray = [sixteenthTile1IsOn,
                                      sixteenthTile2IsOn,
                                      sixteenthTile3IsOn,
                                      sixteenthTile4IsOn,
                                      sixteenthTile5IsOn,
                                      sixteenthTile6IsOn,
                                      sixteenthTile7IsOn,
                                      sixteenthTile8IsOn,
                                      sixteenthTile9IsOn,
                                      sixteenthTile10IsOn,
                                      sixteenthTile11IsOn,
                                      sixteenthTile12IsOn,
                                      sixteenthTile13IsOn,
                                      sixteenthTile14IsOn,
                                      sixteenthTile15IsOn,
                                      sixteenthTile16IsOn,
                                                        ]
            
            sixteenthTileArray.forEach { tile in
                
                
                    if tile == true {
                        
                        print(tile)
                        do {
                            eighthSoundEffect = try AVAudioPlayer(contentsOf: eighthUrl)
                            eighthSoundEffect?.play()
                        } catch {
                            // couldn't load file :(
                        }

                        
                        
                    } else if tile == false {
                        
                        print(tile)
                        
                        
                        
                    }
                    usleep(250000)
                }
                
                
            
        }
        
        
        
    }
    //which page are we on?
    @objc func nextButtonPressed(sender: UIButton!) {
        
        pageNumber += 1
        print(pageNumber + 1)
        if pageNumber == 1 {
                
            pageTwo()
            
        } else if pageNumber == 2 {
            
            pageThree()
            
        } else if pageNumber == 3 {
            
            pageFour()
            
        } else if pageNumber == 4 {
            
            pageFive()
            
        } else if pageNumber == 5 {
            
            pageSix()
            
        } else if pageNumber == 6 {
            
            pageSeven()
            
        } else if pageNumber == 7 {
            
            pageEight()
            
        } else if pageNumber == 8 {
            
            pageNine()
            
        } else if pageNumber == 9 {
            
            pageTen()
            
        } else if pageNumber == 10 {
            
            pageEleven()
            
        } else if pageNumber == 11 {
            
            pageTwelve()
            
        } else if pageNumber == 12 {
            
            pageThirteen()
            
        } else if pageNumber == 13 {
            
            pageFourteen()
            
        } else if pageNumber == 14 {
            
            pageOne()
            pageNumber = 0
        }
        
        
    }
    
    @objc func quarterTile1Pressed(sender: UIButton!) {
        
        if quarterTile1isOn == false {
            
            quarterTile1isOn = true
            print("you turned quarter tile 1 on.")
            quarterTile1.setImage(quarterImageUp, for: .normal)

            
        } else if quarterTile1isOn == true {
            
            quarterTile1isOn = false
            print("you turned quarter tile 1 off")
            quarterTile1.setImage(quarterImageDown, for: .normal)
        }
    }
    
    @objc func quarterTile2Pressed(sender: UIButton!) {
        
        if quarterTile2isOn == false {
            
            quarterTile2isOn = true
            print("you turned quarter tile 2 on.")
            quarterTile2.setImage(quarterImageUp, for: .normal)

            
        } else if quarterTile2isOn == true {
            
            quarterTile2isOn = false
            print("you turned quarter tile 2 off")
            quarterTile2.setImage(quarterImageDown, for: .normal)
        }
        
       
    }
    
    @objc func quarterTile3Pressed(sender: UIButton!) {
        
        if quarterTile3isOn == false {
            
            quarterTile3isOn = true
            print("you turned quarter tile 3 on.")
            quarterTile3.setImage(quarterImageUp, for: .normal)

            
        } else if quarterTile3isOn == true {
            
            quarterTile3isOn = false
            print("you turned quarter tile 3 off")
            quarterTile3.setImage(quarterImageDown, for: .normal)
        }
        
        
    }
    
    @objc func quarterTile4Pressed(sender: UIButton!) {
        
        if quarterTile4isOn == false {
            
            quarterTile4isOn = true
            print("you turned quarter tile 4 on.")
            quarterTile4.setImage(quarterImageUp, for: .normal)

            
        } else if quarterTile4isOn == true {
            
            quarterTile4isOn = false
            print("you turned quarter tile 4 off")
            quarterTile4.setImage(quarterImageDown, for: .normal)
        }
        
    }
    
    @objc func wholeNotePressed(sender: UIButton!) {
        
        do {
            quarterSoundEffect = try AVAudioPlayer(contentsOf: quarterUrl)
            quarterSoundEffect?.play()
        } catch {
            // couldn't load file :(
        }
        UIView.animate(withDuration: 1) {
            wholeNoteView.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
        }
        //UIView.animate(withDuration: 1) {
        //    view.transform = CGAffineTransformScale(viewsOriginalTransform, 0.5, 0.5);
        //}
    }
    
    
    @objc func eighthTile1Pressed(sender: UIButton!) {
        
        if eighthTile1IsOn == false {
            
            eighthTile1IsOn = true
            print("you turned eighth tile 1 on.")
            eighthTile1.setImage(eighthImageUp, for: .normal)

            
        } else if eighthTile1IsOn == true {
            
            eighthTile1IsOn = false
            print("you turned eighth tile 1 off")
            eighthTile1.setImage(eighthImageDown, for: .normal)
        }
        
    }
    
    @objc func eighthTile2Pressed(sender: UIButton!) {
        
        if eighthTile2IsOn == false {
            
            eighthTile2IsOn = true
            print("you turned eighth tile 1n on.")
            eighthTile2.setImage(eighthImageUp, for: .normal)

            
        } else if eighthTile2IsOn == true {
            
            eighthTile2IsOn = false
            print("you turned eighth tile 1n off")
            eighthTile2.setImage(eighthImageDown, for: .normal)
        }
        
    }
    
    @objc func eighthTile3Pressed(sender: UIButton!) {
        
        if eighthTile3IsOn == false {
            
            eighthTile3IsOn = true
            print("you turned eighth tile 2 on.")
            eighthTile3.setImage(eighthImageUp, for: .normal)

            
        } else if eighthTile3IsOn == true {
            
            eighthTile3IsOn = false
            print("you turned eighth tile 2 off")
            eighthTile3.setImage(eighthImageDown, for: .normal)
        }
        
    }
    
    @objc func eighthTile4Pressed(sender: UIButton!) {
        
        if eighthTile4IsOn == false {
            
            eighthTile4IsOn = true
            print("you turned eighth tile 2n on.")
            eighthTile4.setImage(eighthImageUp, for: .normal)

            
        } else if eighthTile4IsOn == true {
            
            eighthTile4IsOn = false
            print("you turned eighth tile 2n off")
            eighthTile4.setImage(eighthImageDown, for: .normal)
        }
        
    }
    
    @objc func eighthTile5Pressed(sender: UIButton!) {
        
        if eighthTile5IsOn == false {
            
            eighthTile5IsOn = true
            print("you turned eighth tile 3 on.")
            eighthTile5.setImage(eighthImageUp, for: .normal)

            
        } else if eighthTile5IsOn == true {
            
            eighthTile5IsOn = false
            print("you turned eighth tile 3 off")
            eighthTile5.setImage(eighthImageDown, for: .normal)
        }
        
    }
    
    @objc func eighthTile6Pressed(sender: UIButton!) {
        
        if eighthTile6IsOn == false {
            
            eighthTile6IsOn = true
            print("you turned eighth tile 3n on.")
            eighthTile6.setImage(eighthImageUp, for: .normal)

            
        } else if eighthTile6IsOn == true {
            
            eighthTile6IsOn = false
            print("you turned eighth tile 3n off")
            eighthTile6.setImage(eighthImageDown, for: .normal)
        }
        
    }
    
    @objc func eighthTile7Pressed(sender: UIButton!) {
        
        if eighthTile7IsOn == false {
            
            eighthTile7IsOn = true
            print("you turned eighth tile 4 on.")
            eighthTile7.setImage(eighthImageUp, for: .normal)

            
        } else if eighthTile7IsOn == true {
            
            eighthTile7IsOn = false
            print("you turned eighth tile 4 off")
            eighthTile7.setImage(eighthImageDown, for: .normal)
        }
        
    }
    
    @objc func eighthTile8Pressed(sender: UIButton!) {
        
        if eighthTile8IsOn == false {
            
            eighthTile8IsOn = true
            print("you turned eighth tile 4n on.")
            eighthTile8.setImage(eighthImageUp, for: .normal)

            
        } else if eighthTile8IsOn == true {
            
            eighthTile8IsOn = false
            print("you turned eighth tile 4n off")
            eighthTile8.setImage(eighthImageDown, for: .normal)
        }
        
    }
    
    
    //sixteenth note if statements
    @objc func sixteenthTile1Pressed(sender: UIButton!) {
        if sixteenthTile1IsOn == false {
            
            sixteenthTile1IsOn = true
            print("you turned sixteenth tile 1 on.")
            sixteenthTile1.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile1IsOn == true {
            
            sixteenthTile1IsOn = false
            print("you turned sixteenth tile 1 off.")
            sixteenthTile1.setImage(sixteenthImageDown, for: .normal)
        }
    }
    
    @objc func sixteenthTile2Pressed(sender: UIButton!) {
        if sixteenthTile2IsOn == false {
            
            sixteenthTile2IsOn = true
            print("you turned sixteenth tile 1e on.")
            sixteenthTile2.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile2IsOn == true {
            
            sixteenthTile2IsOn = false
            print("you turned sixteenth tile 1e on.")
            sixteenthTile2.setImage(sixteenthImageDown, for: .normal)
            
        }
    }
    
    @objc func sixteenthTile3Pressed(sender: UIButton!) {
        if sixteenthTile3IsOn == false {
            
            sixteenthTile3IsOn = true
            print("you turned sixteenth tile 1n on.")
            sixteenthTile3.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile3IsOn == true {
            
            sixteenthTile3IsOn = false
            print("you turned sixteenth tile 1n on.")
            sixteenthTile3.setImage(sixteenthImageDown, for: .normal)
            
        }
    }
    
    @objc func sixteenthTile4Pressed(sender: UIButton!) {
        if sixteenthTile4IsOn == false {
            
            sixteenthTile4IsOn = true
            print("you turned sixteenth tile 1a on.")
            sixteenthTile4.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile4IsOn == true {
            
            sixteenthTile4IsOn = false
            print("you turned sixteenth tile 1a on.")
            sixteenthTile4.setImage(sixteenthImageDown, for: .normal)
            
        }
    }
    
    @objc func sixteenthTile5Pressed(sender: UIButton!) {
        if sixteenthTile5IsOn == false {
            
            sixteenthTile5IsOn = true
            print("you turned sixteenth tile 2 on.")
            sixteenthTile5.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile5IsOn == true {
            
            sixteenthTile5IsOn = false
            print("you turned sixteenth tile 2 off.")
            sixteenthTile5.setImage(sixteenthImageDown, for: .normal)
        }
    }
    
    @objc func sixteenthTile6Pressed(sender: UIButton!) {
        if sixteenthTile6IsOn == false {
            
            sixteenthTile6IsOn = true
            print("you turned sixteenth tile 2e on.")
            sixteenthTile6.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile6IsOn == true {
            
            sixteenthTile6IsOn = false
            print("you turned sixteenth tile 2e on.")
            sixteenthTile6.setImage(sixteenthImageDown, for: .normal)
            
        }
    }
    
    @objc func sixteenthTile7Pressed(sender: UIButton!) {
        if sixteenthTile7IsOn == false {
            
            sixteenthTile7IsOn = true
            print("you turned sixteenth tile 2n on.")
            sixteenthTile7.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile7IsOn == true {
            
            sixteenthTile7IsOn = false
            print("you turned sixteenth tile 2n on.")
            sixteenthTile7.setImage(sixteenthImageDown, for: .normal)
            
        }
    }
    
    @objc func sixteenthTile8Pressed(sender: UIButton!) {
        if sixteenthTile8IsOn == false {
            
            sixteenthTile8IsOn = true
            print("you turned sixteenth tile 2a on.")
            sixteenthTile8.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile8IsOn == true {
            
            sixteenthTile8IsOn = false
            print("you turned sixteenth tile 2a on.")
            sixteenthTile8.setImage(sixteenthImageDown, for: .normal)
            
        }
    }
    
    @objc func sixteenthTile9Pressed(sender: UIButton!) {
        if sixteenthTile9IsOn == false {
            
            sixteenthTile9IsOn = true
            print("you turned sixteenth tile 3 on.")
            sixteenthTile9.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile9IsOn == true {
            
            sixteenthTile9IsOn = false
            print("you turned sixteenth tile 3 off.")
            sixteenthTile9.setImage(sixteenthImageDown, for: .normal)
        }
    }
    
    @objc func sixteenthTile10Pressed(sender: UIButton!) {
        if sixteenthTile10IsOn == false {
            
            sixteenthTile10IsOn = true
            print("you turned sixteenth tile 3e on.")
            sixteenthTile10.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile10IsOn == true {
            
            sixteenthTile10IsOn = false
            print("you turned sixteenth tile 3e on.")
            sixteenthTile10.setImage(sixteenthImageDown, for: .normal)
            
        }
    }
    
    @objc func sixteenthTile11Pressed(sender: UIButton!) {
        if sixteenthTile11IsOn == false {
            
            sixteenthTile11IsOn = true
            print("you turned sixteenth tile 3n on.")
            sixteenthTile11.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile11IsOn == true {
            
            sixteenthTile11IsOn = false
            print("you turned sixteenth tile 3n on.")
            sixteenthTile11.setImage(sixteenthImageDown, for: .normal)
            
        }
    }
    
    @objc func sixteenthTile12Pressed(sender: UIButton!) {
        if sixteenthTile12IsOn == false {
            
            sixteenthTile12IsOn = true
            print("you turned sixteenth tile 3a on.")
            sixteenthTile12.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile12IsOn == true {
            
            sixteenthTile12IsOn = false
            print("you turned sixteenth tile 3a on.")
            sixteenthTile12.setImage(sixteenthImageDown, for: .normal)
            
        }
    }
    
    @objc func sixteenthTile13Pressed(sender: UIButton!) {
        if sixteenthTile13IsOn == false {
            
            sixteenthTile13IsOn = true
            print("you turned sixteenth tile 4 on.")
            sixteenthTile13.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile13IsOn == true {
            
            sixteenthTile13IsOn = false
            print("you turned sixteenth tile 4 off.")
            sixteenthTile13.setImage(sixteenthImageDown, for: .normal)
        }
    }
    
    @objc func sixteenthTile14Pressed(sender: UIButton!) {
        if sixteenthTile14IsOn == false {
            
            sixteenthTile14IsOn = true
            print("you turned sixteenth tile 4e on.")
            sixteenthTile14.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile14IsOn == true {
            
            sixteenthTile14IsOn = false
            print("you turned sixteenth tile 4e on.")
            sixteenthTile14.setImage(sixteenthImageDown, for: .normal)
            
        }
    }
    
    @objc func sixteenthTile15Pressed(sender: UIButton!) {
        if sixteenthTile15IsOn == false {
            
            sixteenthTile15IsOn = true
            print("you turned sixteenth tile 4n on.")
            sixteenthTile15.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile15IsOn == true {
            
            sixteenthTile15IsOn = false
            print("you turned sixteenth tile 4n on.")
            sixteenthTile15.setImage(sixteenthImageDown, for: .normal)
            
        }
    }
    
    @objc func sixteenthTile16Pressed(sender: UIButton!) {
        if sixteenthTile16IsOn == false {
            
            sixteenthTile16IsOn = true
            print("you turned sixteenth tile 4a on.")
            sixteenthTile16.setImage(sixteenthImageUp, for: .normal)

            
        } else if sixteenthTile16IsOn == true {
            
            sixteenthTile16IsOn = false
            print("you turned sixteenth tile 4a on.")
            sixteenthTile16.setImage(sixteenthImageDown, for: .normal)
            
        }
    }
    
   
    //pages!
    
    func pageOne() {
        fullReset()
        startButton.isHidden = true
        pageText.isHidden = false
        centerText.isHidden = true
        nextButton.setTitle("Next > ", for: .normal)
        backButton.alpha = 0
        nextButton.isHidden = false
        playButton.isHidden = true
        quarterStackView.isHidden = true
        page3StackView.isHidden = true
        
        UIView.animate(withDuration: 1) {
            pageText.alpha = 1.0
            notationExampleView.alpha = 1.0
            
        }
        pageText.text = ("Today, we will be learning about note values specifically in the context of playing the drums! By the end of this, you will have created your own beat. In music notation, note values indicate the duration of a note, or how long you play the note for. ")
        notationExampleView.isHidden = false
        self.view.addSubview(titleImageView)
        self.view.addSubview(pageText)
        self.view.addSubview(nextButton)
        self.view.addSubview(pageText)
        self.view.addSubview(playButton)
        self.view.addSubview(quarterStackView)
        
        
        titleImageView.isHidden = true
        titleSubtext.isHidden = true
        titleIconView.isHidden = true
        
    }
    
    
    
    
    
    
    
    
    func pageTwo() {
        fullReset()
        notationExampleView.isHidden = true
        wholeNoteView.alpha = 0
        pageText.alpha = 0
        backButton.isHidden = false
        pageText.text = "To make things even simpler, we'll just focus on quarter, eighth and sixteenth notes. "
        
        page3StackView.isHidden = false
        staffExampleView.isHidden = true
        UIView.animate(withDuration: 1) {
            pageText.alpha = 1.0
            page3StackView.alpha = 1.0
            backButton.alpha = 1.0
            quarterExView.image = UIImage(named: "quarterReal.png")
            eighthExView.image = UIImage(named: "eighthReal.png")
            sixteenthExView.image = UIImage(named: "sixteenthReal.png")
        }
        
    }
    
    func pageThree() {
        fullReset()
        pageText.alpha = 0
        page3StackView.alpha = 0
        eighthStackView.isHidden = true
        staffExampleView.isHidden = true
        wholeNoteView.isHidden = true
        UIView.animate(withDuration: 1) {
            
            pageText.text = "These will be represented by tiles for now."
            pageText.alpha = 1
            quarterExView.image = UIImage(named: "quarterUp.png")
            eighthExView.image = UIImage(named: "eighthNumberEx.png")
            sixteenthExView.image = UIImage(named: "sixteenExNumber.png")
            page3StackView.alpha = 1
            
            
        }
        
        
    }
    
    func pageFour() {
        fullReset()
        
        staffExampleView.isHidden = false
        pageText.alpha = 0
        UIView.animate(withDuration: 1) {
            pageText.alpha = 1.0
            staffExampleView.alpha = 1.0
            wholeNoteView.alpha = 1.0
        }
        eighthStackView.alpha = 1.0
        pageText.text = "Notes are grouped into bars, also called measures. In one bar, there is one whole note. Simple, right? Click the whole note to hear what it sounds like. (Whole notes are rarely used in music, but they are good to know about.)"
        notationExampleView.isHidden = true
        wholeNoteView.isHidden = false
        page3StackView.isHidden = true
        quarterStackView.isHidden = true
        hideQuarterCountGuides()
        
    }
    
    func pageFive() {
        fullReset()
        staffExampleView.isHidden = true
        wholeNoteView.isHidden = true
        pageText.alpha = 0
        showQuarterTiles()
        pageText.text = "In one whole note, there are four quarter notes, hence the name. The time it takes to play one whole note is the same as playing four quarter notes. Now, we get to play around with quarter notes to see what patterns we can make. Click next to proceed."
        quarterStackView.isHidden = false
        playButton.isHidden = true
        showQuarterCountGuides()
        playButton.alpha = 0
        quarterStackView.alpha = 0
        UIView.animate(withDuration: 1) {
            pageText.alpha = 1.0
            quarterStackView.alpha = 1.0
            playButton.alpha = 1.0
            countGuide1.alpha = 1.0
            countGuide2.alpha = 1.0
            countGuide3.alpha = 1.0
            countGuide4.alpha = 1.0
        }
        
        
        
    }
    
    func pageSix() {
        fullReset()
        showQuarterTiles()
        resetQuarterTiles()
        hideEighthTiles()
        pageText.text = "For example, click on all of the tiles and hit play to hear a basic quarter note beat. To hear your pattern, click the play button."
        playButton.isHidden = false
        resetButton.isHidden = false
        view.bringSubviewToFront(quarterStackView)
    }
    
    func pageSeven() {
        fullReset()
        pageText.text = "Now, try alternating tiles. Click on one and three, or two and four. Then, press play. To turn off a tile, click it again, or press the reset tiles button. Hear the difference? When there is no sound (or in our case when the tile is off), we call that a rest."
        
        resetQuarterTiles()
        hideEighthTiles()
        showQuarterTiles()
        view.bringSubviewToFront(quarterStackView)
    
    }
    
    func pageEight() {
        fullReset()
        hideQuarterTiles()
        hideQuarterCountGuides()
        eighthStackView.isHidden = false
        pageText.text = "Quarter notes can further be divided into two, called eighth notes. Tap all of the tiles and hit play to hear a basic eighth note beat."
        showEighthTiles()
        showEighthCountGuides()
        UIView.animate(withDuration: 1) {
            eighthStackView.alpha = 1.0
            
        }
        
        view.bringSubviewToFront(eighthStackView)
        
        
    }
    
    
    func pageNine() {
        fullReset()
        resetButton.isHidden = false
        resetEighthTiles()
        showEighthCountGuides()
        showEighthTiles()
        eighthStackView.alpha = 0
        pageText.alpha = 0
        pageText.text = "Now, try tapping tile 1,2,3 and 4 and press play. This should sound like the quarter note beat. Tile 1, 2, 3 and 4 are essentially quarter notes, and tiles 1n, 2n, 3n, and 4n are the notes in between them. Hint: to turn off a tile, tap it again. To reset all of the tiles, click the reset tiles button under the play button."
        UIView.animate(withDuration: 1) {
            eighthStackView.alpha = 1.0
            pageText.alpha = 1.0
            
        }
        eighthStackView.isHidden = false
        
    }
    
    func pageTen() {
        fullReset()
        pageText.text = "Try playing around with the tiles. Try adding spaces in between the tiles, or even a few in a row. Experiment!"
        resetEighthTiles()
        eighthStackView.isHidden = false
        hideSixteenthTiles()
        showEighthTiles()
        showEighthCountGuides()
        eighthStackView.alpha = 1
        view.bringSubviewToFront(eighthStackView)
        sixteenthStackView.isHidden = true
    }
    
    func pageEleven() {
        fullReset()
        showSixteenGuides()
        showSixteenthTiles()
        eighthStackView.isHidden = true
        hideEighthTiles()
        pageText.text = "Eighth tiles can also be divided into two, called sixteenth notes. Tap all of the tiles and press play to hear a basic sixteenth note beat."
        eighthGuide1.isHidden = true
        eighthGuide2.isHidden = true
        eighthGuide3.isHidden = true
        eighthGuide4.isHidden = true
        eighthGuide5.isHidden = true
        eighthGuide6.isHidden = true
        eighthGuide7.isHidden = true
        eighthGuide8.isHidden = true
        sixteenthStackView.isHidden = false
        self.view.bringSubviewToFront(sixteenthStackView)
    }
    
    func pageTwelve() {
        
        fullReset()
        showSixteenGuides()

        resetSixteenthTiles()
        pageText.text = "Try clicking on tiles 1, 2, 3, 4, 1n, 2n, 3n, and 4n. Don't forget to hit play! This should sound like a eighth note beat. "
        showSixteenthTiles()
    }
    
    func pageThirteen() {
        
        fullReset()
        showSixteenGuides()
        resetSixteenthTiles()
        pageText.text = "Play around with the tiles to see the patterns you can make yourself. Turn on a few tiles in a row, or leave a few out. Have fun!"
        showSixteenthTiles()
    }
    
    func pageFourteen() {
        //ending page! you did it! Now, you should now the basics of note values and rhythm. Great job! Thank you for taking the time to play my submission. Have a great day/night! also: add a button
        centerText.isHidden = false
        fullReset()
        playButton.isHidden = true
        backButton.isHidden = true
        pageText.isHidden = true
        sixteenthStackView.isHidden = true
        resetButton.isHidden = true
        nextButton.setTitle("Play Again >" ,for:.normal)
        centerText.text = "You did it! Now, you should know the basics of note values and rhythm. Great job! Thank you for taking the time to play my submission."
        
        hideSixteenGuides()
        
    }
    
    func resetQuarterTiles() {
        
        quarterTile1isOn = false
        quarterTile2isOn = false
        quarterTile3isOn = false
        quarterTile4isOn = false
        quarterTile1.setImage(quarterImageDown, for: .normal)
        quarterTile2.setImage(quarterImageDown, for: .normal)
        quarterTile3.setImage(quarterImageDown, for: .normal)
        quarterTile4.setImage(quarterImageDown, for: .normal)
    }
    
    func hideQuarterTiles() {
        
        quarterTile1.isHidden = true
        quarterTile2.isHidden = true
        quarterTile3.isHidden = true
        quarterTile4.isHidden = true
    }
    
    func resetEighthTiles() {
        
        eighthTile1IsOn = false
        eighthTile2IsOn = false
        eighthTile3IsOn = false
        eighthTile4IsOn = false
        eighthTile5IsOn = false
        eighthTile6IsOn = false
        eighthTile7IsOn = false
        eighthTile8IsOn = false
        eighthTile1.setImage(eighthImageDown, for: .normal)
        eighthTile2.setImage(eighthImageDown, for: .normal)
        eighthTile3.setImage(eighthImageDown, for: .normal)
        eighthTile4.setImage(eighthImageDown, for: .normal)
        eighthTile5.setImage(eighthImageDown, for: .normal)
        eighthTile6.setImage(eighthImageDown, for: .normal)
        eighthTile7.setImage(eighthImageDown, for: .normal)
        eighthTile8.setImage(eighthImageDown, for: .normal)
    }
    
    func resetSixteenthTiles() {
        sixteenthTile1IsOn = false
        sixteenthTile2IsOn = false
        sixteenthTile3IsOn = false
        sixteenthTile4IsOn = false
        sixteenthTile5IsOn = false
        sixteenthTile6IsOn = false
        sixteenthTile7IsOn = false
        sixteenthTile8IsOn = false
        
        sixteenthTile9IsOn = false
        sixteenthTile10IsOn = false
        sixteenthTile11IsOn = false
        sixteenthTile12IsOn = false
        sixteenthTile13IsOn = false
        sixteenthTile14IsOn = false
        sixteenthTile15IsOn = false
        sixteenthTile16IsOn = false
        
        sixteenthTile1.setImage(sixteenthImageDown, for: .normal)
        sixteenthTile2.setImage(sixteenthImageDown, for: .normal)
        sixteenthTile3.setImage(sixteenthImageDown, for: .normal)
        sixteenthTile4.setImage(sixteenthImageDown, for: .normal)
        sixteenthTile5.setImage(sixteenthImageDown, for: .normal)
        sixteenthTile6.setImage(sixteenthImageDown, for: .normal)
        sixteenthTile7.setImage(sixteenthImageDown, for: .normal)
        sixteenthTile8.setImage(sixteenthImageDown, for: .normal)
        
        sixteenthTile9.setImage(sixteenthImageDown, for: .normal)
        sixteenthTile10.setImage(sixteenthImageDown, for: .normal)
        sixteenthTile11.setImage(sixteenthImageDown, for: .normal)
        sixteenthTile12.setImage(sixteenthImageDown, for: .normal)
        sixteenthTile13.setImage(sixteenthImageDown, for: .normal)
        sixteenthTile14.setImage(sixteenthImageDown, for: .normal)
        sixteenthTile15.setImage(sixteenthImageDown, for: .normal)
        sixteenthTile16.setImage(sixteenthImageDown, for: .normal)
        
    }
    func showQuarterCountGuides() {
        countGuide1.isHidden = false
        countGuide2.isHidden = false
        countGuide3.isHidden = false
        countGuide4.isHidden = false
    }
    

    
    @objc func resetButtonPressed(sender:UIButton!) {
        
        resetQuarterTiles()
        resetEighthTiles()
        resetSixteenthTiles()
    }
    
    func hideQuarterCountGuides() {
        countGuide1.isHidden = true
        countGuide2.isHidden = true
        countGuide3.isHidden = true
        countGuide4.isHidden = true
    }
    
    func hideEighthTiles() {
        
        eighthTile1.isHidden = true
        eighthTile2.isHidden = true
        eighthTile3.isHidden = true
        eighthTile4.isHidden = true
        
        eighthTile5.isHidden = true
        eighthTile6.isHidden = true
        eighthTile7.isHidden = true
        eighthTile8.isHidden = true
    }
    
    func showEighthTiles() {
        
        eighthTile1.isHidden = false
        eighthTile2.isHidden = false
        eighthTile3.isHidden = false
        eighthTile4.isHidden = false
        
        eighthTile5.isHidden = false
        eighthTile6.isHidden = false
        eighthTile7.isHidden = false
        eighthTile8.isHidden = false
    }

    
    func showQuarterTiles() {
        
        quarterTile1.isHidden = false
        quarterTile2.isHidden = false
        quarterTile3.isHidden = false
        quarterTile4.isHidden = false
    }
    
    func hideSixteenthTiles() {
        
        sixteenthTile1.isHidden = true
        sixteenthTile2.isHidden = true
        sixteenthTile3.isHidden = true
        sixteenthTile4.isHidden = true
        
        sixteenthTile5.isHidden = true
        sixteenthTile6.isHidden = true
        sixteenthTile7.isHidden = true
        sixteenthTile8.isHidden = true
        
        sixteenthTile9.isHidden = true
        sixteenthTile10.isHidden = true
        sixteenthTile11.isHidden = true
        sixteenthTile12.isHidden = true
        
        sixteenthTile13.isHidden = true
        sixteenthTile14.isHidden = true
        sixteenthTile15.isHidden = true
        sixteenthTile16.isHidden = true
        
        
        sixteenthStackView.isHidden = true
    }
    
    func showSixteenthTiles() {
        
        sixteenthTile1.isHidden = false
        sixteenthTile2.isHidden = false
        sixteenthTile3.isHidden = false
        sixteenthTile4.isHidden = false
        
        sixteenthTile5.isHidden = false
        sixteenthTile6.isHidden = false
        sixteenthTile7.isHidden = false
        sixteenthTile8.isHidden = false
        
        sixteenthTile9.isHidden = false
        sixteenthTile10.isHidden = false
        sixteenthTile11.isHidden = false
        sixteenthTile12.isHidden = false
        
        sixteenthTile13.isHidden = false
        sixteenthTile14.isHidden = false
        sixteenthTile15.isHidden = false
        sixteenthTile16.isHidden = false
        
        
        sixteenthStackView.isHidden = false
    }
    
    func showEighthCountGuides() {
        
        eighthGuide1.isHidden = false
        eighthGuide1.alpha = 1
        eighthGuide3.isHidden = false
        eighthGuide3.alpha = 1
        eighthGuide5.isHidden = false
        eighthGuide5.alpha = 1
        eighthGuide7.isHidden = false
        eighthGuide7.alpha = 1
        eighthGuide2.isHidden = false
        eighthGuide2.alpha = 1
        eighthGuide4.isHidden = false
        eighthGuide4.alpha = 1
        eighthGuide6.isHidden = false
        eighthGuide6.alpha = 1
        eighthGuide8.isHidden = false
        eighthGuide8.alpha = 1
    }
    
    
    func showSixteenGuides() {
        
        sixteenGuide1.isHidden = false
        sixteenGuide2.isHidden = false
        sixteenGuide3.isHidden = false
        sixteenGuide4.isHidden = false
        
        sixteenGuide5.isHidden = false
        sixteenGuide6.isHidden = false
        sixteenGuide7.isHidden = false
        sixteenGuide8.isHidden = false
        
        sixteenGuide9.isHidden = false
        sixteenGuide10.isHidden = false
        sixteenGuide11.isHidden = false
        sixteenGuide12.isHidden = false
        
        sixteenGuide13.isHidden = false
        sixteenGuide14.isHidden = false
        sixteenGuide15.isHidden = false
        sixteenGuide16.isHidden = false
    }
    
    func hideSixteenGuides() {
        
        sixteenGuide1.isHidden = true
        sixteenGuide2.isHidden = true
        sixteenGuide3.isHidden = true
        sixteenGuide4.isHidden = true
        
        sixteenGuide5.isHidden = true
        sixteenGuide6.isHidden = true
        sixteenGuide7.isHidden = true
        sixteenGuide8.isHidden = true
        
        sixteenGuide9.isHidden = true
        sixteenGuide10.isHidden = true
        sixteenGuide11.isHidden = true
        sixteenGuide12.isHidden = true
        
        sixteenGuide13.isHidden = true
        sixteenGuide14.isHidden = true
        sixteenGuide15.isHidden = true
        sixteenGuide16.isHidden = true
    }
    
    func fullReset() {
        resetQuarterTiles()
        resetEighthTiles()
        resetSixteenthTiles()
    }
}






let master = ViewController()
master.preferredContentSize = .init(width: 750, height: 500)
PlaygroundPage.current.liveView = master

